Hi there!

This program was made by MarioS271 to make it easier for you to personalize your Windows 11 PC.
By executing Install.bat, the app wil be fully installed.

I have to say, the file 'ExplorerPatcher_SETUP.exe' wasn't made by me. I just added it here because it's
a very cool tool made by valinet (https://github.com/valinet).
Check the program out at 'https://github.com/valinet/ExplorerPatcher'.


DISCLAIMER: ONLY INSTALL THIS ON WINDOWS 11, BECAUSE IT DOES STUFF THAT MAY CAUSE SYSTEM ERRORS ON OTHER
            VERSIONS THAN WINDOWS 11!!!!